// SBS Program Data - Weeks 1-20 from Excel
// This file is auto-generated from the Excel spreadsheet

const PROGRAM_WEEKS = JSON.parse(require('fs').readFileSync('/home/ubuntu/SBS2/weeks_data.json', 'utf8'));
const AMRAP_HISTORY = JSON.parse(require('fs').readFileSync('/home/ubuntu/SBS2/amrap_history.json', 'utf8'));
